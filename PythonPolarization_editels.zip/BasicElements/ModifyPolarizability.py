import sys
sys.path.append('../')
from BasicElements import Molecule,Position, Polarizability
from BasicElements.MoleculeFactory import ReadMoleculeType
from BasicElements.MoleculeFactory import GetMolecule
#from Polarizability.GetDipoles import *
from BasicElements import *
import numpy as np

def ModifyPolarizability(molecule, C, H, S):
	""" takes a mol and changes the isotropic polarizability
	for each atom
	"""
	C = Polarizability(iso=C)
	H = Polarizability(iso=H)
	S = Polarizability(iso=S)
	for atom in molecule: 
		if (atom()._elname==C):
			atom()._pol= C
       		elif (atom()._elname==H):
			atom()._pol= H
		elif (atom()._elname==S):
			atom()._pol= S
	molecule()
"""
Usage example:

mol = GetMolecule('12T_no_charge.xyz')

#ModifyPolarizability(mol(), 4.)
#print mol()

polrange    = np.arange(4., 9., .5)
cutoffrange = np.arange(3., 10., .5)

print "# polarizability(au^3) cutoff(au) total dipole  "
for p in polrange:
	ModifyPolarizability(mol(), p)
	for  c in cutoffrange:
		d = get_dipoles(E0=np.matrix([10.,0.,0.]),cutoff=c)
		split_d = split_dipoles_onto_atoms(d)
		tot = np.matrix([0.,0.,0.])
		for dd in split_d:
		     tot += dd	
		print p, c, tot[0,0]
"""
