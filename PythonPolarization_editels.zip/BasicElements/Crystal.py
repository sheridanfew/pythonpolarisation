
from Molecule import Molecule
from MoleculeFactory import ReadMoleculeType
from MoleculeFactory import GetMolecule
from Rotation import Rotation as rot
from Position import Position
#from RegisterMolecules import RegisterMolecules as _rm
from Register import RegisteredObject, GetRegister

import numpy as np

#eg. sexi_top=Crystal(mols_cen,mols_sur,TVs,cenpos,maxTVs,lena,lenb,lenc)
#sexitopcrystal=Crystal(mols_cen=['sexi_cat_mola','sexi_neut_molb'],mols_sur=['sexi_neut_mola','sexi_neut_molb'],cenpos=[0,0,0],TVs,maxTVs,lena,lenb,lenc)


class Crystal ( RegisteredObject, list):
	"""A base crystal class
	"""

	def __init__(self, **kwargs):
		list.__init__(self)
		self._type = "BaseClass"
		self._name = kwargs.get('name')
		self._cenpos = kwargs.get('cenpos')

		mols_cen = kwargs.get('mols_cen')
		mols_sur = kwargs.get('mols_sur')
		cenpos = kwargs.get('cenpos')
		TVs = kwargs.get('TVs')
		lena = kwargs.get('lena')
		lenb = kwargs.get('lenb')
		lenc = kwargs.get('lenc')

		maxTVs = kwargs.get('maxTVs','nomax')
	

		# maxTVs doesn't need to be specified, but allows the creation of a diamondlike shape. This will set a maximum number of TVs in any direction from cenpos. Otherwise, a cuboid will be created with lengths in a, b, c, as specified by max and min posns. (10000 assumed to be large enough that we will never reach this limit)


		for i in np.arange(0,len(mols_cen),1):
				ReadMoleculeType('../Molecules/%s' % mols_cen[i])
				ReadMoleculeType('../Molecules/%s' % mols_sur[i])

		print 'type(mols_cen)', type(mols_cen)
		self._mols=	[ [[[] for i in range(lenb+1)] for i in range(lena+1)] for __ in xrange(len(mols_cen))]
		print 'self._mols', self._mols
		#self._mols will contains all molecules.
		#mols[0] contains a list of all molecules in position a, mols[1] all mols in pos'n b, etc.
		#mols[0][x][y][z] contains molecule a in position x,y,z
		#mols may as such be iterated over in a number of ways to consider different molecules.
		#Need to make list the correct length in mols, a, b. We then append in c (see below)

		for a in np.arange(0,lena+1,1):
			for b in np.arange(0,lenb+1,1):
				for c in np.arange(0,lenc+1,1):
					if a == cenpos[0] and b == cenpos[1] and c == cenpos[2]:
						#central mol
						for i in np.arange(0,len(mols_cen),1):
							print 'iabc', i, a, b, c
							print self._mols
							self._mols[i][a][b].append(GetMolecule('../Molecules/%s' % mols_cen[i]))
							self._mols[i][a][b][c]().RedCoordMove(TVs=TVs, movevec=[a,b,c])
					elif maxTVs == 'nomax' or (abs(a)-cenpos[0])+(abs(b)-cenpos[1])+(abs(c)-cenpos[2]) <= maxTVs:
						# Places molecule of this type if not in centres[0], and, if specified, less than MaxTVs translation vectors from centre unit cell.
						for i in np.arange(0,len(mols_sur),1):
							print 'iabc', i, a, b, c
							print 'maxTVs', maxTVs
							self._mols[i][a][b].append(GetMolecule('../Molecules/%s' % mols_sur[i]))
							print 'self._mols[i][a][b][c]', self._mols[i][a][b][c]
							print 'type(self._mols[i][a][b][c])', type(self._mols[i][a][b][c])
							print 'type(self._mols[i][a][b][c]())', type(self._mols[i][a][b][c]())
							#print 'WARNING: Not moving mols to correct posn'
							self._mols[i][a][b][c]().RedCoordMove(TVs=TVs, movevec=[a,b,c])
					else:
						for i in np.arange(0,len(mols_sur),1):
							self._mols[i][a][b].append('empty')

	def rotate(self, r):
		"""rotates the crystal by rotation r
		"""
		if not isinstance(r,rot):
			raise TypeError('must rotate molecules by a rotation')

		for a in range(0,len(self._mols[0]),1):
			for b in range(0,len(self._mols[0][0]),1):
				for c in range(0,len(self._mols[0][0][0]),1):
					for molincell in range(0,len(self._mols),1):
						if mols[molincell][a][b][c] != 'empty':
							self._mols[molincell][a][b][c].rotate(r)

	def move(self, d):
		"""moves crystal by d


		"""
		for a in range(0,len(self._mols[0]),1):
			for b in range(0,len(self._mols[0][0]),1):
				for c in range(0,len(self._mols[0][0][0]),1):
					for molincell in range(0,len(self._mols),1):
						if mols[molincell][a][b][c] != 'empty':
							self._mols[molincell][a][b][c].move(d)		

	def print_posns(self):
		# new.dats for gnuplot with individual molecules
		for a in range(0,len(self._mols[0]),1):
			for b in range(0,len(self._mols[0][0]),1):
				for c in range(0,len(self._mols[0][0][0]),1):
					for molincell in range(0,len(self._mols),1):
						if self._mols[molincell][a][b][c] != 'empty':
							f = open('%s_size_%s_pos_%s%s%s_mol%s.dat' % (self._name,(len(self._mols[0])*len(self._mols[0][0])*len(self._mols[0][0][0])),a,b,c,molincell), 'w')
							f.write('Molecule Starts:\n')
							for molecule in self._mols[molincell][a][b][c]():
								print 'making posns file'
								molstr=str(molecule())
								for atom in GetRegister('Atom'):
									astr=str(atom)
									if molstr in astr:
										f.write(astr)
										f.write('\n')
										f.write('Molecule Ends.')
										f.flush()
										f.close()


