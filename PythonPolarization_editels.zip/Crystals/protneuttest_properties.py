import numpy as np

name='protneuttest'
size=
ncentres=

posns=[[] for i in range(4) ]
dips=[[] for i in range(4) ]
atomtype=[[] for i in range(4) ]
#Initiate lists for atom properties.
#eg. posns[3][7] is position of atom 7 of mol 3.

names=[]
reorgseV=[]
#reorgseV[2] is reorganisation energy associated with swapping charges of central mol and mol 2 without changing polar environment.

TVs=np.matrix([[1.8897261,0.0000000,0.0000000],[0.0000000,1.8897261,0.0000000],[0.0000000,0.0000000,1.8897261]])

names.append('prot_neut_size_27_pos_222_mol0.dat')
names.append('prot_neut_size_27_pos_222_mol1.dat')
names.append('prot_neut_size_27_pos_000_mol0.dat')
names.append('prot_neut_size_27_pos_000_mol1.dat')
posns[1][1].append(np.array([3.7794522,3.7794522,3.7794522]))
posns[2][1].append(np.array([4.7794523,3.7794522,3.7794522]))
posns[3][1].append(np.array([0.0000000,0.0000000,0.0000000]))
posns[4][1].append(np.array([1.0000000,0.0000000,0.0000000]))
dips[1][1].append(np.array([0.0425884,0.0426757,0.0426757]))
dips[2][1].append(np.array([0.0347896,0.0232736,0.0232736]))
dips[3][1].append(np.array([-0.0413425,-0.0436199,-0.0436199]))
dips[4][1].append(np.array([-0.0313580,-0.0706547,-0.0706547]))
atomtype[1][1].append('neut')
atomtype[2][1].append('neut')
atomtype[3][1].append('neut')
atomtype[4][1].append('neut')
reorgseV.append('')
reorgseV.append('')
reorgseV.append('')
reorgseV.append('')
