import sys
sys.path.append('../')

from BasicElements import *
import numpy as np
from BasicElements.Register import GetRegister

def get_atoms_with_polarizability():
	n=0
	for i, atom in GetRegister('Atom'):
		if atom._haspol:	
			n+=1
	return n

class JMatrix(object):
	"""J Matrix creates the J matrix, as defined in Stern paper
	
	by looking up the register of atoms, it should automatically fill in the whole
	matrix when the object is initialised JMatrix._m will return the underlying matrix
	the JMatrix can be initialised with a certain cutoff 

	"""
	def __init__(self, **kwargs):
		natom   = get_atoms_with_polarizability()
		self._m = np.asmatrix(np.zeros((natom*3,natom*3)) ) # initialise an empty matrix
		self._cutoff = kwargs.get('cutoff', 0.)       # SHERIDAN : this sets the cutoff. the default value I set is 0.
							      # you need to check this default value - think about units etc.	 
		self.fill_matrix()
	
#	def fill_matrix(self):
#	#NB. Using JK def. here as was having problems.
#		""" this is automatically done when the JMatrix is initialised
#		
#		in principle you can call fill_matrix after the JMatrix has been initialised 
#			
#		"""
#		row = 0
#		for k, atom1 in GetRegister('Atom'):
#			if not atom1._haspol: # skip atoms that do not have polarizability
#				continue	
#			col = 0
#			for k2, atom2 in GetRegister('Atom'):
#				if not atom2._haspol:
#					continue	
#				self.fill_elements(row, col, atom1, atom2)
#				col +=1
#			row+=1


	def fill_matrix(self):
		""" this is automatically done when the JMatrix is initialised
		
		in principle you can call fill_matrix after the JMatrix has been initialised 
			
		"""
		row = 0
		for k, atom1 in GetRegister('Atom'):
#			print 'atom 1'
#			print atom1._haspol
#			print atom1._pol
#			print np.linalg.det(atom1._pol)
#			print k
			if np.linalg.det(atom1._pol)==0.0: # skip atoms that do not have polarizability
				print "atom does not have pol,(or pol is a singular matrix with no determinant), skipping  NB. This has caused problems so far! Python says makes Jmat a singular matrix..."
				continue	
			col = 0
			for k2, atom2 in GetRegister('Atom'):
#				print 'atom 2'
#				print atom2._haspol
#				print k2
				if np.linalg.det(atom2._pol)==0.0:
					print "atom does not have pol,skipping"
					continue
				self.fill_elements(row, col, atom1, atom2)
				col +=1
			row+=1
			
	
	def get_element(self,atom1, atom2):
		""" computes the submatrices that fit into the J_BB' matrix"""
		if atom1 is atom2 :
			""" the diagonal components J_BB are the inverse of the polarizability

			SHERIDAN: you can check this is true by looking up the definition on page 4731, second column just after equation 4

			"""
			return atom1._pol.I # SF I is identity matrix
		else: 
			""" the off-diagonal components J_BB' are described in equation 11

			SHERIDAN: I think that there is an obvious typo in equaiton 11.
	
			"""
			dV = atom2._pos-atom1._pos #SHERIDAN: check that I have worked out the distance vector the right way round!
			d = dV.abs()
			I = np.mat(np.eye(3))          # this generates a3x3 identity matrix
			if d >= self._cutoff:
				return 1./d**3            * (I - 3. * (dV.T * dV )/d**2 )	#SHERIDAN: to understand how numpy does linear algebra
												# I suggest playing with it. the way i defined the positions
												# _pos.T * _pos gives you the "outer" product
												#_pos * _pos._T gives you the dot product
			else:
#				print dV, d, self._cutoff
#				print type(dV)
#				print type(d)
#				print type(self._cutoff)
#				print 'self._cutoff, dV, d, atom2._crg, atom1._crg', self._cutoff, dV, d, atom2._crg, atom1._crg
#				print 'atom2._parent, atom1._parent', atom2._parent, atom1._parent
#				print 'atom2._pos, atom1._pos', atom2._pos, atom1._pos
				#print '1./', self._cutoff, '**3 * (', I, ' - 3. * (', dV.T, ' * ', dV, ')/', d, '**2 )'
				#print '1./self._cutoff**3 * (I - 3. * (dV.T * dV )/d**2 )', 1./self._cutoff**3 * (I - 3. * (dV.T * dV )/d**2 )

				print 'atom1,2'
				print atom1.__repr__()
				print atom2.__repr__()
				print ''

				try:
				  element=1./self._cutoff**3 * (I - 3. * (dV.T * dV )/d**2 )
				except ZeroDivisionError:
				  print "divide by zero"
				  exit(2)
				return element
				#return 1./self._cutoff**3 * (I - 3. * (dV.T * dV )/d**2 )
	
	def fill_elements(self,row, col, atom1, atom2):	
		"""this function computes the block element and adds it in at the correct row and col
			
		row and col refer to the position of the atom in the atom register. in order to convert
		this to an index for self._m, row and col must be multiplied by 3 - as each atom contributes
		three coordinates,x,y and z	
	
		"""
		mat = self.get_element(atom1, atom2) 
#		print mat
		for i in range(3):
			for j in range(3):
				self._m[row*3+i, col*3+j] = mat[i,j]

